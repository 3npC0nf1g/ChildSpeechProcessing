# ════════════════════════════════════════════════════════════════════════════
# MAIN.PY - Point d'entrée principal
# ════════════════════════════════════════════════════════════════════════════

import sys
from pathlib import Path
from typing import Optional, Dict, Any
import json
import pickle
from datetime import datetime

from config import Config


class MFAPipeline:
    """
    Classe principale pour orchestrer tout le pipeline MFA.
    
    Gère l'exécution des zones en séquence, sauvegarde/charge les résultats,
    et fournit un logging détaillé.
    """
    
    def __init__(self, config: Optional[Config] = None):
        """
        Initialize le pipeline.
        
        Args:
            config: Configuration object (use default if None)
        """
        self.config = config or Config()
        self.config.create_directories()
        self.config.print_config()
        
        # Résultats des zones
        self.results = {}
        
        # Timestamp du run
        self.run_timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        print(f"✅ Pipeline initialized (Run: {self.run_timestamp})\n")
    
    def run_all_zones(self, start_zone: int = 0, end_zone: int = 9):
        """
        Exécuter toutes les zones du pipeline dans l'ordre.
        
        Args:
            start_zone: Première zone à exécuter (0-9)
            end_zone: Dernière zone à exécuter (0-9)
        """
        
        print("\n" + "="*80)
        print(f"RUNNING MFA PIPELINE (Zones {start_zone}-{end_zone})")
        print("="*80 + "\n")
        
        try:
            for zone_num in range(start_zone, end_zone + 1):
                self.run_zone(zone_num)
                
                # Save intermediate results
                self.save_results(zone_num)
            
            print("\n" + "="*80)
            print("✅ PIPELINE COMPLETE")
            print("="*80)
            print(f"\nOutput directory: {self.config.OUTPUT_DIR}")
            print(f"Results saved: {self.run_timestamp}\n")
            
        except Exception as e:
            print(f"\n❌ PIPELINE FAILED at zone")
            print(f"Error: {str(e)}\n")
            raise
    
    def run_zone(self, zone_num: int) -> Any:
        """
        Exécuter une zone spécifique.
        
        Args:
            zone_num: Numéro de zone (0-9)
            
        Returns:
            Résultat de la zone
        """
        
        if zone_num == 0:
            return self._run_zone_0()
        elif zone_num == 1:
            return self._run_zone_1()
        elif zone_num == 2:
            return self._run_zone_2()
        elif zone_num == 3:
            return self._run_zone_3()
        elif zone_num == 4:
            return self._run_zone_4()
        elif zone_num == 5:
            return self._run_zone_5()
        elif zone_num == 6:
            return self._run_zone_6()
        elif zone_num == 7:
            return self._run_zone_7()
        elif zone_num == 8:
            return self._run_zone_8()
        elif zone_num == 9:
            return self._run_zone_9()
        else:
            raise ValueError(f"Invalid zone number: {zone_num}")
    
    # ────────────────────────────────────────────────────────────────────────
    # ZONE IMPLEMENTATIONS
    # ────────────────────────────────────────────────────────────────────────
    
    def _run_zone_0(self):
        """Zone 0: Install Dependencies"""
        print("\n" + "="*80)
        print("ZONE 0: INSTALL DEPENDENCIES")
        print("="*80 + "\n")
        
        print("Installing required packages...")
        import subprocess
        
        packages = [
            "librosa",
            "soundfile",
            "numpy",
            "pandas",
            "matplotlib",
            "seaborn",
            "tqdm",
            "openai-whisper",
            "jiwer",
        ]
        
        for package in packages:
            try:
                __import__(package.replace("-", "_"))
                print(f"  ✓ {package}")
            except ImportError:
                print(f"  Installing {package}...")
                subprocess.check_call(
                    [sys.executable, "-m", "pip", "install", "-q", package, 
                     "--break-system-packages" if self.config.IS_COLAB else ""]
                )
        
        # MFA special handling
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "-q",
                                  "Montreal-Forced-Aligner", 
                                  "--break-system-packages" if self.config.IS_COLAB else ""])
            print(f"  ✓ Montreal-Forced-Aligner")
        except:
            print(f"  ⚠️  MFA installation may require manual setup")
        
        print("\n✅ Zone 0 complete\n")
        self.results[0] = {'status': 'complete'}
        return self.results[0]
    
    def _run_zone_1(self):
        """Zone 1: File Matching"""
        print("\n" + "="*80)
        print("ZONE 1: FILE MATCHING")
        print("="*80 + "\n")
        
        # TODO: Implémenter le matching logique
        print("Matching .cha ↔ Audio files...")
        print(f"  CHA dir: {self.config.CHA_DIR}")
        print(f"  Audio dir: {self.config.AUDIO_DIR}")
        
        # Exemple:
        cha_files = list(self.config.CHA_DIR.glob(f"*{self.config.CHA_EXTENSION}"))
        audio_files = []
        for ext in self.config.AUDIO_EXTENSIONS:
            audio_files.extend(self.config.AUDIO_DIR.glob(f"*{ext}"))
        
        print(f"  Found {len(cha_files)} .cha files")
        print(f"  Found {len(audio_files)} audio files")
        
        print("\n✅ Zone 1 complete\n")
        self.results[1] = {
            'status': 'complete',
            'cha_files': len(cha_files),
            'audio_files': len(audio_files)
        }
        return self.results[1]
    
    def _run_zone_2(self):
        """Zone 2: Segment Extraction"""
        print("\n" + "="*80)
        print("ZONE 2: SEGMENT EXTRACTION FROM .CHA")
        print("="*80 + "\n")
        
        print("Extracting word-level segments from .cha files...")
        # TODO: Implémenter l'extraction
        
        print("\n✅ Zone 2 complete\n")
        self.results[2] = {'status': 'complete', 'segments': 0}
        return self.results[2]
    
    def _run_zone_3(self):
        """Zone 3: MFA Alignment"""
        print("\n" + "="*80)
        print("ZONE 3: MFA ALIGNMENT")
        print("="*80 + "\n")
        
        print("Running Montreal Forced Aligner...")
        print(f"  Model: {self.config.MFA_MODEL_NAME}")
        # TODO: Implémenter l'alignement MFA
        
        print("\n✅ Zone 3 complete\n")
        self.results[3] = {'status': 'complete', 'aligned': 0}
        return self.results[3]
    
    def _run_zone_4(self):
        """Zone 4: Audio Segmentation"""
        print("\n" + "="*80)
        print("ZONE 4: AUDIO SEGMENTATION")
        print("="*80 + "\n")
        
        print("Segmenting audio files with MFA timestamps...")
        # TODO: Implémenter la segmentation
        
        print("\n✅ Zone 4 complete\n")
        self.results[4] = {'status': 'complete', 'segments': 0}
        return self.results[4]
    
    def _run_zone_5(self):
        """Zone 5: Speaker Metadata"""
        print("\n" + "="*80)
        print("ZONE 5: EXTRACT SPEAKER METADATA")
        print("="*80 + "\n")
        
        print("Extracting speaker information...")
        # TODO: Implémenter l'extraction de métadonnées
        
        print("\n✅ Zone 5 complete\n")
        self.results[5] = {'status': 'complete', 'speakers': 0}
        return self.results[5]
    
    def _run_zone_6(self):
        """Zone 6: Merge Segments"""
        print("\n" + "="*80)
        print("ZONE 6: MERGE SEGMENTS (10-30 seconds)")
        print("="*80 + "\n")
        
        print(f"Merging segments to target duration: {self.config.TARGET_DURATION_SEC}s")
        # TODO: Implémenter la fusion
        
        print("\n✅ Zone 6 complete\n")
        self.results[6] = {'status': 'complete', 'merged': 0}
        return self.results[6]
    
    def _run_zone_7(self):
        """Zone 7: Data Quality Analysis"""
        print("\n" + "="*80)
        print("ZONE 7: DATA QUALITY ANALYSIS (WITH VAD)")
        print("="*80 + "\n")
        
        print(f"Analyzing quality with VAD (threshold: {self.config.QUALITY_THRESHOLD})...")
        # TODO: Implémenter l'analyse qualité
        
        print("\n✅ Zone 7 complete\n")
        self.results[7] = {'status': 'complete', 'quality_segments': 0}
        return self.results[7]
    
    def _run_zone_8(self):
        """Zone 8: Whisper Baseline Evaluation"""
        print("\n" + "="*80)
        print("ZONE 8: WHISPER BASELINE EVALUATION (OPTIONAL)")
        print("="*80 + "\n")
        
        print(f"Evaluating with Whisper model: {self.config.WHISPER_MODEL}")
        # TODO: Implémenter l'évaluation
        
        print("\n✅ Zone 8 complete\n")
        self.results[8] = {'status': 'complete', 'wer': 0.0}
        return self.results[8]
    
    def _run_zone_9(self):
        """Zone 9: Create Training Dataset"""
        print("\n" + "="*80)
        print("ZONE 9: CREATE TRAINING DATASET")
        print("="*80 + "\n")
        
        print("Creating training dataset...")
        print(f"  Output: {self.config.DATASET_DIR}")
        # TODO: Implémenter la création du dataset
        
        print("\n✅ Zone 9 complete\n")
        self.results[9] = {'status': 'complete', 'dataset_path': str(self.config.DATASET_DIR)}
        return self.results[9]
    
    # ────────────────────────────────────────────────────────────────────────
    # SAVING AND LOADING
    # ────────────────────────────────────────────────────────────────────────
    
    def save_results(self, zone_num: int):
        """Sauvegarder les résultats d'une zone"""
        
        output_file = self.config.LOGS_DIR / f"zone_{zone_num}_results_{self.run_timestamp}.json"
        
        with open(output_file, 'w') as f:
            json.dump(self.results[zone_num], f, indent=2, default=str)
        
        print(f"  Saved: {output_file}")
    
    def load_results(self, zone_num: int, timestamp: Optional[str] = None):
        """Charger les résultats d'une zone"""
        
        if timestamp is None:
            timestamp = self.run_timestamp
        
        result_file = self.config.LOGS_DIR / f"zone_{zone_num}_results_{timestamp}.json"
        
        if result_file.exists():
            with open(result_file, 'r') as f:
                return json.load(f)
        else:
            raise FileNotFoundError(f"Results not found: {result_file}")
    
    def get_results(self) -> Dict[str, Any]:
        """Retourner tous les résultats"""
        return self.results
    
    def print_summary(self):
        """Afficher un résumé du pipeline"""
        
        print("\n" + "="*80)
        print("PIPELINE SUMMARY")
        print("="*80 + "\n")
        
        for zone_num, result in sorted(self.results.items()):
            status = "✅" if result.get('status') == 'complete' else "❌"
            print(f"  Zone {zone_num}: {status} {result}")
        
        print("\n" + "="*80 + "\n")


# ════════════════════════════════════════════════════════════════════════════
# MAIN ENTRY POINT
# ════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    
    # Parse command line arguments
    import argparse
    
    parser = argparse.ArgumentParser(description="MFA Pipeline")
    parser.add_argument("--zone", type=int, default=None,
                       help="Run specific zone (0-9)")
    parser.add_argument("--start", type=int, default=0,
                       help="Start from zone")
    parser.add_argument("--end", type=int, default=9,
                       help="End at zone")
    
    args = parser.parse_args()
    
    # Create and run pipeline
    pipeline = MFAPipeline()
    
    if args.zone is not None:
        # Run specific zone
        pipeline.run_zone(args.zone)
    else:
        # Run range of zones
        pipeline.run_all_zones(args.start, args.end)
    
    # Print summary
    pipeline.print_summary()
