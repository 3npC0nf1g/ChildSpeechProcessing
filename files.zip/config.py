# ════════════════════════════════════════════════════════════════════════════
# CONFIG.PY - Configuration centralisée
# ════════════════════════════════════════════════════════════════════════════

from pathlib import Path
from typing import Tuple, Optional
import os


class Config:
    """Configuration centralisée pour tout le projet MFA Pipeline"""
    
    # ────────────────────────────────────────────────────────────────────────
    # PATHS (Ajuster pour votre setup)
    # ────────────────────────────────────────────────────────────────────────
    
    # Détection automatique si Colab
    IS_COLAB = 'COLAB_RELEASE_TAG' in os.environ
    
    # Répertoires de base
    if IS_COLAB:
        BASE_DIR = Path("/content")
        DATA_DIR = Path("/content/data")
        OUTPUT_DIR = Path("/content/output")
    else:
        BASE_DIR = Path.cwd()
        DATA_DIR = Path.cwd() / "data"
        OUTPUT_DIR = Path.cwd() / "output"
    
    # Sous-répertoires data
    CHA_DIR = DATA_DIR / "cha"
    AUDIO_DIR = DATA_DIR / "audio"
    
    # Sous-répertoires output
    SEGMENTED_AUDIO_DIR = OUTPUT_DIR / "segmented_audio"
    MERGED_SEGMENTS_DIR = OUTPUT_DIR / "merged_segments"
    DATASET_DIR = OUTPUT_DIR / "dataset"
    LOGS_DIR = OUTPUT_DIR / "logs"
    VISUALIZATIONS_DIR = OUTPUT_DIR / "visualizations"
    
    # ────────────────────────────────────────────────────────────────────────
    # ZONE PARAMETERS
    # ────────────────────────────────────────────────────────────────────────
    
    # Zone 3: MFA Alignment
    MFA_MODEL_NAME = "english_us_arpa"
    MFA_CLEAN_INTERMEDIATE = True
    MFA_VERBOSE = True
    
    # Zone 4: Audio Segmentation
    AUDIO_SAMPLE_RATE = 16000
    AUDIO_PAD_MS = 50
    AUDIO_OVERWRITE = False
    
    # Zone 6: Merge Segments
    TARGET_DURATION_SEC: Tuple[float, float] = (10, 30)
    MERGE_STRATEGY = "greedy"
    
    # Zone 7: Data Quality Analysis
    QUALITY_THRESHOLD = 0.7
    VAD_USE_ENHANCED = True
    VAD_ENERGY_PERCENTILE = 30
    VAD_ZCR_PERCENTILE = 60
    VAD_SPECTRAL_PERCENTILE = 40
    
    # Quality scoring rules
    QUALITY_RULES = {
        'speech_rate': {
            'min': 0.5,
            'max': 6.0,
            'penalty': 0.3
        },
        'duration': {
            'min_ms': 5000,
            'max_ms': 60000,
            'penalty': 0.2
        },
        'text_length': {
            'min_chars': 10,
            'penalty': 0.1
        },
        'speech_activity': {
            'min_ratio': 0.4,
            'penalty': 0.25
        },
        'energy': {
            'min_mean': 0.01,
            'penalty': 0.1
        },
        'dynamic_range': {
            'min_db': 5.0,
            'penalty': 0.15
        }
    }
    
    # Zone 8: Whisper Baseline
    WHISPER_MODEL = "base"
    WHISPER_DEVICE = "cuda"  # "cpu" ou "cuda"
    WHISPER_BATCH_SIZE = 32
    
    # Zone 9: Dataset Creation
    DATASET_SPLIT = {
        'train': 0.8,
        'val': 0.1,
        'test': 0.1
    }
    
    # ────────────────────────────────────────────────────────────────────────
    # PROCESSING PARAMETERS
    # ────────────────────────────────────────────────────────────────────────
    
    NUM_WORKERS = 4
    BATCH_SIZE = 32
    VERBOSE = True
    DEBUG = False
    
    # ────────────────────────────────────────────────────────────────────────
    # FILE FORMATS
    # ────────────────────────────────────────────────────────────────────────
    
    CHA_EXTENSION = ".cha"
    AUDIO_EXTENSIONS = [".wav", ".mp3", ".flac", ".ogg"]
    
    # ────────────────────────────────────────────────────────────────────────
    # LOGGING
    # ────────────────────────────────────────────────────────────────────────
    
    LOG_LEVEL = "INFO"  # DEBUG, INFO, WARNING, ERROR
    LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    
    # ────────────────────────────────────────────────────────────────────────
    # METHODS
    # ────────────────────────────────────────────────────────────────────────
    
    @classmethod
    def create_directories(cls):
        """Créer tous les répertoires nécessaires"""
        for dir_path in [
            cls.DATA_DIR,
            cls.CHA_DIR,
            cls.AUDIO_DIR,
            cls.OUTPUT_DIR,
            cls.SEGMENTED_AUDIO_DIR,
            cls.MERGED_SEGMENTS_DIR,
            cls.DATASET_DIR,
            cls.LOGS_DIR,
            cls.VISUALIZATIONS_DIR,
        ]:
            dir_path.mkdir(parents=True, exist_ok=True)
    
    @classmethod
    def validate_paths(cls):
        """Valider que les répertoires essentiels existent"""
        required = [cls.CHA_DIR, cls.AUDIO_DIR]
        
        for path in required:
            if not path.exists():
                raise ValueError(f"Required directory not found: {path}")
        
        return True
    
    @classmethod
    def get_config_dict(cls) -> dict:
        """Retourner la configuration en dict"""
        return {
            'base_dir': str(cls.BASE_DIR),
            'data_dir': str(cls.DATA_DIR),
            'output_dir': str(cls.OUTPUT_DIR),
            'is_colab': cls.IS_COLAB,
            'mfa_model': cls.MFA_MODEL_NAME,
            'whisper_model': cls.WHISPER_MODEL,
            'target_duration': cls.TARGET_DURATION_SEC,
            'quality_threshold': cls.QUALITY_THRESHOLD,
            'sample_rate': cls.AUDIO_SAMPLE_RATE,
        }
    
    @classmethod
    def print_config(cls):
        """Afficher la configuration"""
        print("\n" + "="*80)
        print("CONFIGURATION")
        print("="*80)
        
        config_dict = cls.get_config_dict()
        for key, value in config_dict.items():
            print(f"  {key:20s}: {value}")
        
        print("\n" + "="*80 + "\n")


# Export pour utilisation
__all__ = ['Config']
