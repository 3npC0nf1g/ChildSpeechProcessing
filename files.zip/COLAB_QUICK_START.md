# MFA Pipeline - Quick Start (Colab)

## 📋 Étape 1: Setup (Exécuter une fois)

```python
# Clone et setup du projet
!git clone https://github.com/username/mfa_pipeline.git /content/mfa_pipeline 2>/dev/null || echo "Already cloned"
%cd /content/mfa_pipeline
!bash setup_colab.sh
```

## 📁 Étape 2: Préparer les données

```python
# Copier vos données depuis Google Drive
from google.colab import drive
drive.mount('/content/drive')

# Copier les fichiers
!cp -r "/content/drive/MyDrive/your_data/cha_files/"* /content/data/cha/ 2>/dev/null || echo "CHA files already copied"
!cp -r "/content/drive/MyDrive/your_data/audio_files/"* /content/data/audio/ 2>/dev/null || echo "Audio files already copied"

# Vérifier
import os
print(f"CHA files: {len(os.listdir('/content/data/cha'))}")
print(f"Audio files: {len(os.listdir('/content/data/audio'))}")
```

## 🚀 Étape 3: Lancer le pipeline

### Option A: Exécuter tout le pipeline

```python
from main import MFAPipeline
from config import Config

# Créer le pipeline
pipeline = MFAPipeline()

# Exécuter toutes les zones
pipeline.run_all_zones()

# Afficher un résumé
pipeline.print_summary()
```

### Option B: Exécuter zones spécifiques

```python
from main import MFAPipeline

pipeline = MFAPipeline()

# Zone 0: Install (déjà fait par setup_colab.sh)
# pipeline.run_zone(0)

# Zone 1: File Matching
pipeline.run_zone(1)

# Zone 2: Segment Extraction
pipeline.run_zone(2)

# Zone 3: MFA Alignment
pipeline.run_zone(3)

# Zone 4: Audio Segmentation
pipeline.run_zone(4)

# Zone 5: Speaker Metadata
pipeline.run_zone(5)

# Zone 6: Merge Segments
pipeline.run_zone(6)

# Zone 7: Data Quality (with VAD)
pipeline.run_zone(7)

# Zone 8: Whisper Evaluation (optional)
pipeline.run_zone(8)

# Zone 9: Create Dataset
pipeline.run_zone(9)
```

### Option C: Exécuter une plage de zones

```python
from main import MFAPipeline

pipeline = MFAPipeline()

# Zones 1-5
pipeline.run_all_zones(start_zone=1, end_zone=5)

# Zones 6-9
pipeline.run_all_zones(start_zone=6, end_zone=9)
```

## 📊 Étape 4: Accéder aux résultats

```python
# Obtenir tous les résultats
results = pipeline.get_results()
print(results)

# Charger un fichier de résultats spécifique
quality_segments = pipeline.load_results(zone_num=7)

# Accéder aux fichiers de sortie
import os
output_files = os.listdir('/content/output/')
print(output_files)

# Lister les segments audio créés
audio_segments = os.listdir('/content/output/segmented_audio/')
print(f"Created {len(audio_segments)} audio segments")

# Lister le dataset final
dataset_files = os.listdir('/content/output/dataset/')
print(f"Dataset files: {dataset_files}")
```

## 💾 Étape 5: Télécharger les résultats

```python
# Copier les résultats vers Google Drive
!cp -r /content/output/* "/content/drive/MyDrive/mfa_results/"

# Ou créer une archive
!cd /content && zip -r output.zip output/
from google.colab import files
files.download('output.zip')
```

## 🔧 Configuration (Optionnel)

```python
from config import Config

# Afficher la configuration actuelle
Config.print_config()

# Modifier les paramètres
Config.QUALITY_THRESHOLD = 0.8
Config.TARGET_DURATION_SEC = (12, 25)

# Ou charger la config
config_dict = Config.get_config_dict()
print(config_dict)
```

## 🐛 Troubleshooting

```python
# Vérifier les répertoires
import os
from pathlib import Path

for dir_path in [
    '/content/data/cha',
    '/content/data/audio',
    '/content/output',
]:
    exists = os.path.exists(dir_path)
    files = len(os.listdir(dir_path)) if exists else 0
    print(f"{dir_path}: {files} files")

# Vérifier les imports
import sys
sys.path.insert(0, '/content/mfa_pipeline')

try:
    from config import Config
    from main import MFAPipeline
    print("✅ Imports successful")
except ImportError as e:
    print(f"❌ Import error: {e}")

# Voir les logs
import os
logs = os.listdir('/content/output/logs/')
print(f"Logs: {logs}")
```

## 📝 Notes

- La première exécution prendra plus de temps (téléchargement des modèles)
- Les résultats intermédiaires sont sauvegardés automatiquement
- Vous pouvez relancer zones individuelles sans tout refaire
- Les visualisations sont générées dans `/content/output/visualizations/`

## 🆘 Besoin d'aide?

- Voir: `PROJECT_STRUCTURE.md`
- Voir: Documentation dans chaque module
- Vérifier les logs: `/content/output/logs/`
