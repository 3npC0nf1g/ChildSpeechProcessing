#!/bin/bash
# ════════════════════════════════════════════════════════════════════════════
# SETUP_COLAB.SH - Installation pour Google Colab
# ════════════════════════════════════════════════════════════════════════════

echo ""
echo "╔══════════════════════════════════════════════════════════════════════════╗"
echo "║                  MFA PIPELINE - COLAB SETUP                             ║"
echo "╚══════════════════════════════════════════════════════════════════════════╝"
echo ""

# Check if running in Colab
if [ -z "$COLAB_RELEASE_TAG" ]; then
    echo "⚠️  Not running in Colab. Some features may not work."
fi

# ────────────────────────────────────────────────────────────────────────────
# 1. UPDATE SYSTEM
# ────────────────────────────────────────────────────────────────────────────

echo "Step 1: Updating system packages..."
apt-get update -qq
apt-get install -y -qq build-essential ffmpeg > /dev/null 2>&1
echo "  ✓ System updated"

# ────────────────────────────────────────────────────────────────────────────
# 2. INSTALL PYTHON DEPENDENCIES
# ────────────────────────────────────────────────────────────────────────────

echo ""
echo "Step 2: Installing Python dependencies..."

pip install -q librosa --break-system-packages
echo "  ✓ librosa"

pip install -q soundfile --break-system-packages
echo "  ✓ soundfile"

pip install -q numpy pandas scipy --break-system-packages
echo "  ✓ numpy, pandas, scipy"

pip install -q matplotlib seaborn --break-system-packages
echo "  ✓ matplotlib, seaborn"

pip install -q tqdm --break-system-packages
echo "  ✓ tqdm"

pip install -q openai-whisper --break-system-packages
echo "  ✓ openai-whisper"

pip install -q jiwer --break-system-packages
echo "  ✓ jiwer"

pip install -q torch torchaudio --break-system-packages
echo "  ✓ torch, torchaudio"

# ────────────────────────────────────────────────────────────────────────────
# 3. INSTALL MFA (OPTIONAL - can be skipped if not needed)
# ────────────────────────────────────────────────────────────────────────────

echo ""
echo "Step 3: Installing Montreal Forced Aligner..."

pip install -q Montreal-Forced-Aligner --break-system-packages
echo "  ✓ Montreal-Forced-Aligner"

# Try to download MFA model
echo "  Downloading MFA model..."
mfa model download acoustic english_us_arpa > /dev/null 2>&1 || \
  echo "  ⚠️  MFA model download may need manual setup"

# ────────────────────────────────────────────────────────────────────────────
# 4. CREATE DIRECTORY STRUCTURE
# ────────────────────────────────────────────────────────────────────────────

echo ""
echo "Step 4: Creating directory structure..."

mkdir -p /content/data/cha
mkdir -p /content/data/audio
mkdir -p /content/output/segmented_audio
mkdir -p /content/output/merged_segments
mkdir -p /content/output/dataset
mkdir -p /content/output/logs
mkdir -p /content/output/visualizations

echo "  ✓ Directories created:"
echo "    - /content/data/cha (for .cha files)"
echo "    - /content/data/audio (for audio files)"
echo "    - /content/output/* (for results)"

# ────────────────────────────────────────────────────────────────────────────
# 5. MOUNT GOOGLE DRIVE (if in Colab)
# ────────────────────────────────────────────────────────────────────────────

echo ""
echo "Step 5: Ready to mount Google Drive (if needed)"
echo "  Use this code to mount your Drive:"
echo ""
echo "    from google.colab import drive"
echo "    drive.mount('/content/drive')"
echo ""
echo "  Then copy your data:"
echo "    !cp -r /content/drive/MyDrive/your_data/* /content/data/"
echo ""

# ────────────────────────────────────────────────────────────────────────────
# 6. VERIFY INSTALLATION
# ────────────────────────────────────────────────────────────────────────────

echo "Step 6: Verifying installation..."

python3 << 'EOF'
import sys

print("  Checking imports...")
packages = [
    'librosa', 'soundfile', 'numpy', 'pandas', 'scipy',
    'matplotlib', 'seaborn', 'tqdm', 'whisper', 'jiwer',
    'torch', 'torchaudio'
]

success = 0
for package in packages:
    try:
        __import__(package.replace('-', '_'))
        print(f"    ✓ {package}")
        success += 1
    except ImportError:
        print(f"    ✗ {package} (failed)")

print(f"\n  {success}/{len(packages)} packages installed")

if success == len(packages):
    print("  ✓ Installation successful!")
    sys.exit(0)
else:
    print("  ⚠️  Some packages failed to install")
    sys.exit(1)
EOF

# ────────────────────────────────────────────────────────────────────────────
# 7. FINAL SUMMARY
# ────────────────────────────────────────────────────────────────────────────

echo ""
echo "╔══════════════════════════════════════════════════════════════════════════╗"
echo "║                      SETUP COMPLETE ✅                                   ║"
echo "╚══════════════════════════════════════════════════════════════════════════╝"
echo ""
echo "Next steps:"
echo ""
echo "1. Import your data:"
echo "   - Put .cha files in: /content/data/cha"
echo "   - Put audio files in: /content/data/audio"
echo ""
echo "2. Update config.py if needed"
echo ""
echo "3. Run the pipeline:"
echo "   from main import MFAPipeline"
echo "   pipeline = MFAPipeline()"
echo "   pipeline.run_all_zones()"
echo ""
echo "4. Or run specific zones:"
echo "   pipeline.run_zone(1)  # File matching"
echo "   pipeline.run_zone(2)  # Segment extraction"
echo "   pipeline.run_zone(3)  # MFA alignment"
echo "   # ... etc"
echo ""
echo "Documentation: See PROJECT_STRUCTURE.md"
echo ""
