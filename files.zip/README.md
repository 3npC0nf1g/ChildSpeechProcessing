# 🎙️ MFA Data Processing Pipeline

Un pipeline Python complet pour traiter des données audio avec alignement MFA, segmentation, analyse de qualité avec VAD léger, et création de dataset pour fine-tuning Whisper.

## ✨ Features

- ✅ **Modulaire**: Chaque zone est indépendante
- ✅ **Colab-friendly**: Prêt pour Google Colab
- ✅ **MFA Integration**: Montreal Forced Aligner pour alignement acoustique
- ✅ **VAD Model**: Détection d'activité vocale légère (sans dépendances lourdes)
- ✅ **Quality Analysis**: Analyse détaillée de la qualité audio
- ✅ **Segment Merging**: Fusion automatique pour 10-30 secondes
- ✅ **Whisper Evaluation**: Évaluation baseline WER
- ✅ **Auto-save**: Sauvegarde automatique des résultats intermédiaires

## 📁 Structure

```
mfa_pipeline/
├── main.py                      # Point d'entrée principal
├── config.py                    # Configuration centralisée
├── requirements.txt             # Dépendances
├── setup_colab.sh              # Setup pour Colab
│
├── zones/                       # Modules pour chaque zone
│   ├── zone_0_setup.py         # Installation dépendances
│   ├── zone_1_file_matching.py # Appariement fichiers
│   ├── zone_2_segment_extraction.py
│   ├── zone_3_mfa_alignment.py # MFA alignment
│   ├── zone_4_audio_segmentation.py
│   ├── zone_5_speaker_metadata.py
│   ├── zone_6_merge_segments.py
│   ├── zone_7_data_quality.py  # VAD + Quality
│   ├── zone_8_whisper_evaluation.py
│   └── zone_9_create_dataset.py
│
├── models/                      # Classes et modèles
│   ├── segments.py             # Classes segments
│   ├── vad.py                  # VAD model
│   └── quality_scorer.py        # Quality scoring
│
└── utils/                       # Utilitaires
    ├── logger.py               # Logging
    ├── validators.py           # Validation
    └── file_handlers.py        # Gestion fichiers
```

## 🚀 Quick Start

### 1️⃣ Setup (Local)

```bash
# Clone
git clone https://github.com/username/mfa_pipeline.git
cd mfa_pipeline

# Install
pip install -r requirements.txt
bash setup_colab.sh  # ou setup_local.sh

# Préparer données
mkdir -p data/cha data/audio
# Copier .cha et audio files dans data/
```

### 2️⃣ Lancer le pipeline

```python
from main import MFAPipeline
from config import Config

# Créer pipeline
pipeline = MFAPipeline()

# Exécuter tout
pipeline.run_all_zones()

# Ou zones spécifiques
pipeline.run_zone(3)  # Zone 3: MFA
pipeline.run_zone(6)  # Zone 6: Merge
pipeline.run_zone(7)  # Zone 7: Quality
```

### 3️⃣ Récupérer les résultats

```python
# Résultats
results = pipeline.get_results()

# Fichiers
import os
segments = os.listdir('output/segmented_audio/')
dataset = os.listdir('output/dataset/')

print(f"Segments créés: {len(segments)}")
print(f"Dataset prêt: {os.path.exists('output/dataset/manifest.json')}")
```

## 🎯 Pipeline Zones

### Zone 0: Installation ✅
Installation des dépendances et setup

### Zone 1: File Matching
Appariement fichiers .cha ↔ Audio

### Zone 2: Segment Extraction
Extraction segments word-level depuis .cha

### Zone 3: MFA Alignment ⭐
Montreal Forced Aligner pour alignement acoustique

### Zone 4: Audio Segmentation
Découpe audio selon timestamps MFA

### Zone 5: Speaker Metadata
Extraction info speakers depuis .cha

### Zone 6: Merge Segments
Fusion segments pour atteindre 10-30 secondes

### Zone 7: Data Quality + VAD ⭐
- Analyse qualité audio
- Lightweight VAD model
- Filtering automatique

### Zone 8: Whisper Evaluation (Optional)
Évaluation WER baseline

### Zone 9: Create Dataset
Création dataset final pour fine-tuning Whisper

## 🔧 Configuration

Voir `config.py` pour tous les paramètres:

```python
from config import Config

# Afficher config
Config.print_config()

# Modifier paramètres
Config.TARGET_DURATION_SEC = (10, 30)
Config.QUALITY_THRESHOLD = 0.7
Config.VAD_USE_ENHANCED = True
```

## 📊 VAD Model (Zone 7)

Détection d'activité vocale légère basée sur:
- **Energy**: RMS energy detection
- **Zero-Crossing Rate**: Vocal vs unvoiced
- **Spectral Flatness**: Tonal content

Consensus: Au moins 2/3 features d'accord

## 🎓 Examples

### Minimal (tout automatique)
```python
pipeline = MFAPipeline()
pipeline.run_all_zones()
```

### Personnalisé
```python
pipeline = MFAPipeline()
pipeline.run_all_zones(start_zone=1, end_zone=5)  # Zones 1-5
# ... inspecter résultats ...
pipeline.run_all_zones(start_zone=6, end_zone=9)  # Zones 6-9
```

### Progressif
```python
for zone in [1, 2, 3, 4, 5]:
    pipeline.run_zone(zone)
    results = pipeline.get_results()
    print(f"Zone {zone}: {results[zone]}")
```

## 💾 Output

```
output/
├── zone_X_results_*.json       # Résultats de chaque zone
├── segmented_audio/            # Audio segments (Zone 4)
│   ├── *.wav
│   └── manifest.json
├── merged_segments/            # Segments fusionnés (Zone 6)
├── dataset/                    # Dataset final (Zone 9)
│   ├── manifest.json
│   ├── audio/
│   └── metadata.json
├── visualizations/             # Plots et graphiques
└── logs/                       # Fichiers logs
```

## 🔗 Dependencies

- **Audio**: librosa, soundfile, scipy
- **Data**: numpy, pandas
- **ML**: torch, whisper, jiwer
- **Processing**: Montreal-Forced-Aligner
- **Visualization**: matplotlib, seaborn

## 🐛 Troubleshooting

**"Module not found"**
```python
import sys
sys.path.insert(0, '/path/to/mfa_pipeline')
```

**"MFA model not found"**
```bash
mfa model download acoustic english_us_arpa
```

**"Audio file not found"**
```python
# Vérifier chemins dans config.py
Config.print_config()
```

## 📖 Documentation

- **Quick Start**: `COLAB_QUICK_START.md`
- **Project Structure**: `PROJECT_STRUCTURE.md`
- **Each Zone**: Module docstrings

## 🚀 Colab

```python
# Dans Colab:
!git clone https://github.com/username/mfa_pipeline.git /content/mfa_pipeline
%cd /content/mfa_pipeline
!bash setup_colab.sh

from main import MFAPipeline
pipeline = MFAPipeline()
pipeline.run_all_zones()
```

## 📝 Command Line

```bash
# Run all zones
python main.py

# Run specific zone
python main.py --zone 7

# Run range
python main.py --start 1 --end 5
```

## ✅ Testing

```bash
# Run tests
pytest tests/

# Test specific zone
pytest tests/test_zone_3.py

# Coverage
pytest --cov=zones tests/
```

## 📞 Support

- **Issues**: GitHub Issues
- **Questions**: GitHub Discussions
- **Documentation**: See docs/

## 📄 License

MIT License

## 🙏 Credits

- Montreal Forced Aligner (MFA)
- OpenAI Whisper
- Librosa

## ✨ Status

✅ **Production Ready**

Zones: 0-9 ✅  
Testing: Comprehensive ✅  
Documentation: Complete ✅  
Colab Compatibility: ✅  

---

**Made with ❤️ for audio processing**
